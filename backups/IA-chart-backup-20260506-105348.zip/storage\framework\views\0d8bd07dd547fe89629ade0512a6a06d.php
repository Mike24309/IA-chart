<?php $__env->startSection('page-title', $userModel->exists ? 'Modifier utilisateur' : 'Creer utilisateur'); ?>
<?php $__env->startSection('content'); ?>
<?php
    // Cette preparation choisit le role Employe par defaut lors de la creation d un nouvel utilisateur.
    $roleEmploye = $roles->firstWhere('nom', 'employee');
    $roleSelectionne = old('role_id', $userModel->role_id ?? ($roleEmploye->id ?? null));
?>
<form method="POST" action="<?php echo e($userModel->exists ? route('users.update', $userModel) : route('users.store')); ?>" class="card form-grid">
    <?php echo csrf_field(); ?>
    <?php if($userModel->exists): ?>
        <?php echo method_field('PUT'); ?>
    <?php endif; ?>

    <div><label>Nom</label><input type="text" name="name" value="<?php echo e(old('name', $userModel->name)); ?>" required></div>
    <div><label>Email</label><input type="email" name="email" value="<?php echo e(old('email', $userModel->email)); ?>" required></div>
    <div><label>Code de connexion</label><input type="text" name="login_code" value="<?php echo e(old('login_code', $userModel->login_code)); ?>" placeholder="Laissez vide pour generation automatique"></div>
    <div><label>Telephone</label><input type="text" name="phone" value="<?php echo e(old('phone', $userModel->phone)); ?>"></div>
    <div>
        <label>Role</label>
        <select name="role_id" required>
            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($role->id); ?>" <?php if((string) $roleSelectionne === (string) $role->id): echo 'selected'; endif; ?>><?php echo e($role->libelle); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <small class="muted">Par defaut, un nouvel utilisateur est cree comme employe.</small>
    </div>
    <div>
        <label>Mot de passe</label>
        <input type="password" name="password" <?php echo e($userModel->exists ? '' : 'required'); ?>>
        <small class="muted">Utilisez au moins 6 caracteres.</small>
    </div>
    <div>
        <label>Confirmation</label>
        <input type="password" name="password_confirmation" <?php echo e($userModel->exists ? '' : 'required'); ?>>
        <small class="muted">Retapez exactement le meme mot de passe.</small>
    </div>
    <label class="checkbox full"><input type="checkbox" name="is_active" value="1" <?php echo e(old('is_active', $userModel->is_active ?? true) ? 'checked' : ''); ?>><span>Compte actif</span></label>
    <button class="btn btn-primary" type="submit">Enregistrer</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\IA-chart\resources\views\users\form.blade.php ENDPATH**/ ?>