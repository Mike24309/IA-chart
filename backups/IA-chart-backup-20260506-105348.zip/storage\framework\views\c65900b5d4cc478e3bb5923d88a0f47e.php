
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nouveau mot de passe - DEV IA</title>
    <?php if(file_exists(public_path('build/manifest.json'))): ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css']); ?>
    <?php else: ?>
        <link rel="stylesheet" href="<?php echo e(asset('app.css')); ?>?v=<?php echo e(filemtime(public_path('app.css'))); ?>">
    <?php endif; ?>
</head>
<body class="auth-page">
<div class="auth-shell">
    <div class="auth-card">
        <aside class="auth-brand-panel">
            <div class="auth-brand-wave auth-brand-wave-one"></div>
            <div class="auth-brand-wave auth-brand-wave-two"></div>
            <div class="auth-brand-content">
                <div class="auth-brand-logo">DI</div>
                <p class="auth-brand-eyebrow">Securite</p>
                <h1>DEV IA</h1>
            </div>
        </aside>

        <section class="auth-login-panel">
            <div class="auth-login-head">
                <p>Reinitialisation</p>
                <h2>Nouveau mot de passe</h2>
            </div>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger auth-alert">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div><?php echo e($error); ?></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>

            <div class="auth-login-box">
                <form method="POST" action="<?php echo e(route('password.update')); ?>" class="auth-form-grid">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="token" value="<?php echo e($token); ?>">
                    <div>
                        <label for="email">Adresse email</label>
                        <input id="email" type="email" name="email" value="<?php echo e(old('email', $email)); ?>" required>
                    </div>
                    <div>
                        <label for="password">Nouveau mot de passe</label>
                        <input id="password" type="password" name="password" placeholder="Minimum 6 caracteres" required>
                    </div>
                    <div>
                        <label for="password_confirmation">Confirmation</label>
                        <input id="password_confirmation" type="password" name="password_confirmation" placeholder="Retapez le mot de passe" required>
                    </div>
                    <button class="btn auth-submit-btn" type="submit">Enregistrer le nouveau mot de passe</button>
                    <a href="<?php echo e(route('login')); ?>" class="auth-forgot-link">Retour a la connexion</a>
                </form>
            </div>
        </section>
    </div>
</div>
</body>
</html>
<?php /**PATH C:\laragon\www\IA-chart\resources\views\auth\reset-password.blade.php ENDPATH**/ ?>