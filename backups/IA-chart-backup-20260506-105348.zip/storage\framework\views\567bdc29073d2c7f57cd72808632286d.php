<?php $__env->startSection('page-title', $client->exists ? 'Modifier client' : 'Creer client'); ?>
<?php $__env->startSection('content'); ?>
<form method="POST" action="<?php echo e($client->exists ? route('clients.update', $client) : route('clients.store')); ?>" class="card form-grid">
    <?php echo csrf_field(); ?>
    <?php if($client->exists): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
    <div><label>Nom</label><input type="text" name="name" value="<?php echo e(old('name', $client->name)); ?>" required></div>
    <div><label>Postnom</label><input type="text" name="post_name" value="<?php echo e(old('post_name', $client->post_name)); ?>" required></div>
    <div><label>Email</label><input type="email" name="email" value="<?php echo e(old('email', $client->email)); ?>"></div>
    <div><label>Telephone</label><input type="text" name="phone" value="<?php echo e(old('phone', $client->phone)); ?>"></div>
    <div><label>Entreprise</label><input type="text" name="company" value="<?php echo e(old('company', $client->company)); ?>"></div>
    <div class="full"><label>Adresse</label><textarea name="address"><?php echo e(old('address', $client->address)); ?></textarea></div>
    <button class="btn btn-primary" type="submit">Enregistrer</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\IA-chart\resources\views\clients\form.blade.php ENDPATH**/ ?>