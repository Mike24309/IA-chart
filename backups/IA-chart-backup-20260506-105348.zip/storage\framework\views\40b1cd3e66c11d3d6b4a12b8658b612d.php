
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'DEV IA'); ?></title>
    <?php if(file_exists(public_path('build/manifest.json'))): ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php else: ?>
        <link rel="stylesheet" href="<?php echo e(asset('app.css')); ?>?v=<?php echo e(filemtime(public_path('app.css'))); ?>">
        <script src="<?php echo e(asset('app.js')); ?>?v=<?php echo e(filemtime(public_path('app.js'))); ?>" defer></script>
    <?php endif; ?>
</head>
<body class="<?php echo e(auth()->user()->isAdministrator() ? 'role-admin' : 'role-employee'); ?>">
<div class="app-shell">
    
    <aside class="sidebar">
        <div>
            <div class="brand">
                <div class="brand-mark">
                    <?php if($appSettings->logo_path): ?>
                        <img src="<?php echo e(asset('storage/' . $appSettings->logo_path)); ?>?v=<?php echo e($appSettings->updated_at?->timestamp ?? time()); ?>" alt="Logo" class="brand-logo">
                    <?php else: ?>
                        GA
                    <?php endif; ?>
                </div>
                <div>
                    <h1><?php echo e($appSettings->company_name); ?></h1>
                    <p><?php echo e(auth()->user()->isAdministrator() ? 'Administration' : 'Espace employe'); ?></p>
                </div>
            </div>

            <div class="role-panel <?php echo e(auth()->user()->isAdministrator() ? 'role-panel-admin' : 'role-panel-employee'); ?>">
                
                <span class="role-panel-label"><?php echo e(auth()->user()->isAdministrator() ? 'Acces complet' : 'Acces operationnel'); ?></span>
                <strong><?php echo e(auth()->user()->isAdministrator() ? 'Administrateur principal' : 'Employe vente et stock'); ?></strong>
                <p><?php echo e(auth()->user()->isAdministrator() ? 'Vous pilotez les parametres, les utilisateurs et la supervision globale.' : 'Vous creez les ventes, consultez le stock disponible et gerez votre profil.'); ?></p>
            </div>

            <nav class="nav-links">
                <?php if(auth()->user()->isAdministrator()): ?>
                    
                    <a href="<?php echo e(route('dashboard')); ?>" class="<?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>">Dashboard</a>
                    <a href="<?php echo e(route('categories.index')); ?>" class="<?php echo e(request()->routeIs('categories.*') ? 'active' : ''); ?>">Categories</a>
                    <a href="<?php echo e(route('products.index')); ?>" class="<?php echo e(request()->routeIs('products.*') ? 'active' : ''); ?>">Produits</a>
                    <a href="<?php echo e(route('clients.index')); ?>" class="<?php echo e(request()->routeIs('clients.*') ? 'active' : ''); ?>">Clients</a>
                    <a href="<?php echo e(route('invoices.index')); ?>" class="<?php echo e(request()->routeIs('invoices.*') ? 'active' : ''); ?>">Factures</a>
                    <a href="<?php echo e(route('stock-movements.index')); ?>" class="<?php echo e(request()->routeIs('stock-movements.*') ? 'active' : ''); ?>">Mouvements stock</a>
                    <a href="<?php echo e(route('profile.edit')); ?>" class="<?php echo e(request()->routeIs('profile.*') ? 'active' : ''); ?>">Mon profil</a>
                    <a href="<?php echo e(route('settings.edit')); ?>" class="<?php echo e(request()->routeIs('settings.*') || request()->routeIs('users.*') || request()->routeIs('ai.settings.*') ? 'active' : ''); ?>">Parametres</a>
                <?php else: ?>
                    
                    <a href="<?php echo e(route('dashboard')); ?>" class="<?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>">Accueil</a>
                    <a href="<?php echo e(route('invoices.create')); ?>" class="<?php echo e(request()->routeIs('invoices.create') ? 'active' : ''); ?>">Vendre / facturer</a>
                    <a href="<?php echo e(route('invoices.index')); ?>" class="<?php echo e(request()->routeIs('invoices.index') || request()->routeIs('invoices.show') ? 'active' : ''); ?>">Mes factures</a>
                    <a href="<?php echo e(route('products.index')); ?>" class="<?php echo e(request()->routeIs('products.*') ? 'active' : ''); ?>">Stock disponible</a>
                    <a href="<?php echo e(route('profile.edit')); ?>" class="<?php echo e(request()->routeIs('profile.*') ? 'active' : ''); ?>">Mon profil</a>
                <?php endif; ?>
            </nav>
        </div>
        <div class="sidebar-footer">
            <div class="user-badge">
                <?php if(auth()->user()->profile_photo_path): ?>
                    <img src="<?php echo e(asset('storage/' . auth()->user()->profile_photo_path)); ?>?v=<?php echo e(auth()->user()->updated_at?->timestamp ?? time()); ?>" alt="Profil" class="profile-avatar">
                <?php else: ?>
                    <div class="profile-avatar avatar-fallback"><?php echo e(strtoupper(substr(auth()->user()->name, 0, 1))); ?></div>
                <?php endif; ?>
                <div>
                    <strong><?php echo e(auth()->user()->name); ?></strong>
                    <div class="muted"><?php echo e(auth()->user()->resolved_role_label); ?></div>
                </div>
            </div>
            <form method="POST" action="<?php echo e(route('logout')); ?>">
                <?php echo csrf_field(); ?>
                <button class="btn btn-danger btn-block" type="submit">Deconnexion</button>
            </form>
        </div>
    </aside>

    <main class="main-content">
        
        <header class="topbar">
            <div>
                <h2><?php echo $__env->yieldContent('page-title', 'Dashboard'); ?></h2>
                <p class="muted"><?php echo $__env->yieldContent('page-description', 'Gestion commerciale et stock'); ?></p>
            </div>
            <div class="topbar-meta">
                
                <button type="button" class="btn btn-secondary theme-toggle" data-theme-toggle>Mode sombre</button>
                
                <span class="pill role-pill <?php echo e(auth()->user()->isAdministrator() ? 'role-pill-admin' : 'role-pill-employee'); ?>"><?php echo e(auth()->user()->resolved_role_label); ?></span>
                <span class="pill"><?php echo e($appSettings->currency); ?></span>
                <span class="pill">TVA: <?php echo e(number_format((float) $appSettings->default_tax_rate, 2)); ?>%</span>
            </div>
        </header>

        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div><?php echo e($error); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

        <?php echo $__env->yieldContent('content'); ?>
    </main>
</div>
<?php if(auth()->user()->isAdministrator()): ?>
    <script>
        window.aiRoutes = window.aiRoutes || {
            analyze: "<?php echo e(route('ai.analyze')); ?>",
            ask: "<?php echo e(route('ai.ask')); ?>",
            report: "<?php echo e(route('ai.report')); ?>",
        };
    </script>
    <button type="button" class="ai-fab ai-fab-wide" id="ai-fab">🤖 IA</button>
    <aside class="ai-sidepanel" id="ai-sidepanel">
        <div class="ai-sidepanel-head">
            <div>
                <strong>Assistant IA</strong>
                <div class="muted">Audit et explication rapide</div>
            </div>
            <button type="button" class="btn btn-secondary" id="ai-sidepanel-close">Fermer</button>
        </div>
        <div class="stack">
            
            <button type="button" class="btn btn-secondary" id="ai-sidepanel-run-local">Analyse locale</button>
            <button type="button" class="btn btn-primary" id="ai-sidepanel-run">Analyse avec IA</button>
            <button type="button" class="btn btn-secondary" id="ai-sidepanel-summary">Faire un resume</button>
            <button type="button" class="btn btn-secondary" id="ai-sidepanel-ask-open">Poser une question</button>
            <button type="button" class="btn btn-secondary" id="ai-sidepanel-reset">Reinitialiser</button>
            <a href="<?php echo e(route('ai.report')); ?>" class="btn btn-secondary is-disabled" id="ai-sidepanel-download" aria-disabled="true">Telecharger le resume</a>
        </div>
        <div class="stack" id="ai-sidepanel-content">
            <div class="note">
                <div class="note-head">
                    <strong>Source</strong>
                    <span class="status-badge status-info" id="ai-sidepanel-origin-badge">En attente</span>
                </div>
                <div class="muted" id="ai-sidepanel-origin-text">Le panneau indiquera si le resultat vient de l IA ou d une analyse locale.</div>
            </div>
            <p class="muted">Le resume IA s affichera ici apres analyse.</p>
        </div>
    </aside>

    <div class="ai-dialog" id="ai-question-dialog" hidden>
        <div class="ai-dialog-backdrop" data-ai-dialog-close></div>
        <div class="ai-dialog-panel" role="dialog" aria-modal="true" aria-labelledby="ai-dialog-title">
            <div class="ai-dialog-head">
                <div>
                    <strong id="ai-dialog-title">Question a l assistant IA</strong>
                    <div class="muted">Posez votre question dans une vraie boite de dialogue claire et professionnelle.</div>
                </div>
                <button type="button" class="btn btn-secondary" id="ai-dialog-close">Fermer</button>
            </div>
            <form id="ai-dialog-form" class="stack ai-dialog-form">
                <?php echo csrf_field(); ?>
                <label for="ai-dialog-question" class="ai-dialog-label">Votre question</label>
                <textarea id="ai-dialog-question" placeholder="Ecrivez votre question sur l analyse, les ventes, le stock, les factures ou les alertes."></textarea>
                <div class="actions">
                    <button type="submit" class="btn btn-primary">Envoyer la question</button>
                </div>
            </form>
            <div class="ai-dialog-body" id="ai-dialog-body">
                <div class="ai-chat-empty" id="ai-chat-empty">
                    <strong>Assistant IA</strong>
                    <div class="muted">Vos echanges avec l assistant s afficheront ici, dans une presentation plus propre et lisible.</div>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>
</body>
</html>
<?php /**PATH C:\laragon\www\IA-chart\resources\views/layouts/app.blade.php ENDPATH**/ ?>