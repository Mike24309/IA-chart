
<p>Bonjour <?php echo e($facture->client->name); ?>,</p>
<p>Veuillez trouver ci-joint votre facture <?php echo e($facture->invoice_number); ?>.</p>
<p>Merci pour votre confiance.</p>
<?php /**PATH C:\laragon\www\IA-chart\resources\views\emails\invoice.blade.php ENDPATH**/ ?>