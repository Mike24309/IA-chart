<?php $__env->startSection('page-title', 'Journal d’activite'); ?>
<?php $__env->startSection('page-description', 'Traçabilité complète des opérations et actions sensibles'); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="toolbar">
        <form method="GET" class="toolbar-form">
            <input type="text" name="action" value="<?php echo e(request('action')); ?>" placeholder="Rechercher une action">
            <select name="user_id">
                <option value="">Tous les utilisateurs</option>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($user->id); ?>" <?php if((string) request('user_id') === (string) $user->id): echo 'selected'; endif; ?>><?php echo e($user->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <button class="btn btn-secondary" type="submit">Filtrer</button>
        </form>
        <span class="pill">Total: <?php echo e($activities->total()); ?></span>
    </div>

    <div class="table-responsive">
        <table>
            <thead>
            <tr>
                <th>Date</th>
                <th>Utilisateur</th>
                <th>Action</th>
                <th>Cible</th>
                <th>Contexte</th>
            </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($activity->created_at->format('d/m/Y H:i')); ?></td>
                    <td><?php echo e($activity->user?->name ?? 'Systeme'); ?></td>
                    <td><span class="status-badge status-info"><?php echo e(str_replace('_', ' ', $activity->action)); ?></span></td>
                    <td><?php echo e(class_basename((string) $activity->target_type) ?: 'N/A'); ?> <?php if($activity->target_id): ?>#<?php echo e($activity->target_id); ?><?php endif; ?></td>
                    <td class="muted"><?php echo e($activity->ip_address); ?><br><?php echo e(\Illuminate\Support\Str::limit((string) $activity->user_agent, 60)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5">Aucune activite enregistree pour les filtres selectionnes.</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php echo e($activities->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\IA-chart\resources\views\activities\index.blade.php ENDPATH**/ ?>