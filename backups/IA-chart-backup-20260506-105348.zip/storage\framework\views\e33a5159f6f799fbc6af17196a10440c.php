<?php $__env->startSection('page-title', $product->exists ? 'Modifier produit' : 'Creer produit'); ?>
<?php $__env->startSection('content'); ?>
<form method="POST" enctype="multipart/form-data" action="<?php echo e($product->exists ? route('products.update', $product) : route('products.store')); ?>" class="card form-grid">
    <?php echo csrf_field(); ?>
    <?php if($product->exists): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
    <div><label>Nom</label><input type="text" name="name" value="<?php echo e(old('name', $product->name)); ?>" required></div>
    <div><label>Reference</label><input type="text" name="reference" value="<?php echo e(old('reference', $product->reference)); ?>" required></div>
    <div><label>Categorie</label><select name="category_id"><option value="">Aucune</option><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($category->id); ?>" <?php if(old('category_id', $product->category_id) == $category->id): echo 'selected'; endif; ?>><?php echo e($category->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
    <div><label>Photo</label><input type="file" name="photo"></div>
    <div><label>Prix achat</label><input type="number" step="0.01" name="purchase_price" value="<?php echo e(old('purchase_price', $product->purchase_price ?? 0)); ?>" required></div>
    <div><label>Prix vente</label><input type="number" step="0.01" name="sale_price" value="<?php echo e(old('sale_price', $product->sale_price ?? 0)); ?>" required></div>
    <div><label>Stock</label><input type="number" name="stock" value="<?php echo e(old('stock', $product->stock ?? 0)); ?>" required></div>
    <div><label>Stock minimum</label><input type="number" name="minimum_stock" value="<?php echo e(old('minimum_stock', $product->minimum_stock ?? $appSettings->global_minimum_stock)); ?>" required></div>
    <div class="full"><label>Description</label><textarea name="description" required><?php echo e(old('description', $product->description)); ?></textarea></div>
    <button class="btn btn-primary" type="submit">Enregistrer</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\IA-chart\resources\views\products\form.blade.php ENDPATH**/ ?>