<?php $__env->startSection('page-title', $category->exists ? 'Modifier catégorie' : 'Créer catégorie'); ?>
<?php $__env->startSection('content'); ?>
<form method="POST" action="<?php echo e($category->exists ? route('categories.update', $category) : route('categories.store')); ?>" class="card form-grid">
    <?php echo csrf_field(); ?>
    <?php if($category->exists): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
    <div><label>Nom</label><input type="text" name="name" value="<?php echo e(old('name', $category->name)); ?>" required></div>
    <div class="full"><label>Description</label><textarea name="description"><?php echo e(old('description', $category->description)); ?></textarea></div>
    <button class="btn btn-primary" type="submit">Enregistrer</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\IA-chart\resources\views\categories\form.blade.php ENDPATH**/ ?>