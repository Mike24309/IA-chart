<?php $__env->startSection('page-title', 'Mouvements de stock'); ?>
<?php $__env->startSection('page-description', 'Tracabilite des entrees, sorties et ajustements'); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="toolbar">
        <form method="GET" class="toolbar-form">
            <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="Produit, reference, type ou utilisateur">
            <button class="btn btn-secondary" type="submit">Filtrer</button>
            <a href="<?php echo e(route('stock-movements.index')); ?>" class="btn btn-secondary">Reinitialiser</a>
        </form>
    </div>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th>Produit</th>
                    <th>Type</th>
                    <th>Qte</th>
                    <th>Stock</th>
                    <th>Utilisateur</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $movements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($movement->produit->name); ?></td>
                    <td>
                        <span class="status-badge <?php echo e($movement->movement_type === 'entree' ? 'status-success' : ($movement->movement_type === 'sortie' ? 'status-danger' : 'status-warning')); ?>">
                            <?php echo e($movement->movement_type); ?>

                        </span>
                    </td>
                    <td><?php echo e($movement->quantity); ?></td>
                    <td><?php echo e($movement->stock_avant); ?> -> <?php echo e($movement->stock_apres); ?></td>
                    <td><?php echo e($movement->user->name); ?></td>
                    <td><?php echo e($movement->movement_date->format('d/m/Y')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php echo e($movements->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\IA-chart\resources\views\stock-movements\index.blade.php ENDPATH**/ ?>