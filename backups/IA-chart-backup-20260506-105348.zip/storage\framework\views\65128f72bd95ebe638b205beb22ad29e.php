<?php $__env->startSection('page-title', auth()->user()->isAdministrator() ? 'Factures' : 'Mes factures'); ?>
<?php $__env->startSection('page-description', auth()->user()->isAdministrator() ? 'Historique complet des factures avec filtres et actions de gestion' : 'Historique de vos factures avec recherche rapide'); ?>
<?php $__env->startSection('content'); ?>
<div class="card stack">
    <div class="toolbar">
        <div>
            
            <strong><?php echo e(auth()->user()->isAdministrator() ? 'Liste complete des factures' : 'Liste de mes factures'); ?></strong>
        </div>
    </div>

    
    <form method="GET" class="form-grid">
        <div>
            <label>Recherche</label>
            <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="Numero, client ou commercial">
        </div>
        <div class="actions" style="align-items: end;">
            <button class="btn btn-secondary" type="submit">Filtrer</button>
            <a href="<?php echo e(route('invoices.index')); ?>" class="btn btn-secondary">Reinitialiser</a>
        </div>
    </form>

    
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th>Numero</th>
                    <th>Client</th>
                    <th>Creee par</th>
                    <th>Date</th>
                    <th>Total TTC</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($invoice->invoice_number); ?></td>
                    <td><?php echo e($invoice->client->name); ?></td>
                    <td><?php echo e($invoice->user->name); ?></td>
                    <td><?php echo e($invoice->invoice_date->format('d/m/Y')); ?></td>
                    <td><?php echo e(number_format($invoice->total_ttc, 2)); ?> <?php echo e($appSettings->currency); ?></td>
                    <td class="actions">
                        
                        <a href="<?php echo e(route('invoices.show', $invoice)); ?>" class="btn btn-secondary">Voir</a>
                        <a href="<?php echo e(route('invoices.pdf', $invoice)); ?>" class="btn btn-secondary">PDF</a>
                        <?php if(auth()->user()->isAdministrator()): ?>
                            
                            <form method="POST" action="<?php echo e(route('invoices.destroy', $invoice)); ?>" onsubmit="return confirm('Supprimer cette facture et remettre le stock a jour ?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger">Supprimer</button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6">Aucune facture trouvee pour ces filtres.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

    
    <?php echo e($invoices->appends(request()->query())->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\IA-chart\resources\views\invoices\index.blade.php ENDPATH**/ ?>