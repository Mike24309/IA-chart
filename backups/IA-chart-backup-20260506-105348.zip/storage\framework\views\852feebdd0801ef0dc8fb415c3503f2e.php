
<!DOCTYPE html>
<html lang="fr">
<head>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DEV IA</title>
    
    <?php if(file_exists(public_path('build/manifest.json'))): ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css']); ?>
    <?php else: ?>
        <link rel="stylesheet" href="<?php echo e(asset('app.css')); ?>?v=<?php echo e(filemtime(public_path('app.css'))); ?>">
    <?php endif; ?>
</head>
<body class="auth-page">
<div class="auth-shell">
    <div class="auth-card">
        
        <aside class="auth-brand-panel">
            <div class="auth-brand-wave auth-brand-wave-one"></div>
            <div class="auth-brand-wave auth-brand-wave-two"></div>

            <div class="auth-brand-content">
                
                <div class="auth-brand-logo">DI</div>
                <p class="auth-brand-eyebrow">Bienvenue</p>
                <h1>DEV IA</h1>
            </div>
        </aside>

        
        <section class="auth-login-panel">
            <div class="auth-login-head">
                
                <p>Connexion et acces utilisateur</p>
                <h2>DEV IA</h2>
            </div>

            
            <?php if(session('success')): ?>
                <div class="alert alert-success auth-alert"><?php echo e(session('success')); ?></div>
            <?php endif; ?>

            
            <?php if($errors->any()): ?>
                <div class="alert alert-danger auth-alert">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div><?php echo e($error); ?></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>

            <div class="auth-login-box">
                
                <div class="auth-panel active" id="login-panel">
                    <form method="POST" action="<?php echo e(route('login.perform')); ?>" class="auth-form-grid">
                        <?php echo csrf_field(); ?>
                        
                        <div>
                            <label for="login">Email et code de connexion</label>
                            <input id="login" type="text" name="login" value="<?php echo e(old('login')); ?>" placeholder="Entrez votre email ou votre code" required>
                        </div>
                        
                        <div>
                            <label for="password">Mot de passe</label>
                            <input id="password" type="password" name="password" placeholder="Entrez votre mot de passe" required>
                        </div>
                        
                        <label class="auth-remember">
                            <input type="checkbox" name="remember">
                            <span>Se souvenir de moi</span>
                        </label>
                        
                        <a href="<?php echo e(route('password.request')); ?>" class="auth-forgot-link">Mot de passe oublie ?</a>
                        
                        <button class="btn auth-submit-btn" type="submit">Login</button>
                    </form>
                </div>

            </div>
        </section>
    </div>
</div>

<script>
    // Aucun script de bascule n est necessaire ici car les deux formulaires restent visibles.
</script>
</body>
</html>
<?php /**PATH C:\laragon\www\IA-chart\resources\views\auth\login.blade.php ENDPATH**/ ?>