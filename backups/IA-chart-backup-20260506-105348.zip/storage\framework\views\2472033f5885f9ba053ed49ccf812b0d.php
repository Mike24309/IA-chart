<?php $__env->startSection('page-title', 'Creer un mouvement de stock'); ?>
<?php $__env->startSection('content'); ?>
<form method="POST" action="<?php echo e(route('stock-movements.store')); ?>" class="card form-grid">
    <?php echo csrf_field(); ?>
    <div>
        <label>Produit</label>
        <select name="produit_id">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($product->id); ?>"><?php echo e($product->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div>
        <label>Type</label>
        <select name="movement_type">
            <option value="entree">Entree</option>
            <option value="sortie">Sortie</option>
            <option value="ajustement">Ajustement</option>
        </select>
    </div>
    <div>
        <label>Quantite</label>
        <input type="number" name="quantity" required>
    </div>
    <div>
        <label>Nouveau stock (ajustement)</label>
        <input type="number" name="new_stock">
    </div>
    <div class="full">
        <label>Motif</label>
        <input type="text" name="reason" required>
    </div>
    <button class="btn btn-primary" type="submit">Enregistrer</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\IA-chart\resources\views\stock-movements\create.blade.php ENDPATH**/ ?>