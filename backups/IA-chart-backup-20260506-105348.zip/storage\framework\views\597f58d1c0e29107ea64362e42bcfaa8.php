<?php $__env->startSection('page-title', 'Utilisateurs'); ?>
<?php $__env->startSection('page-description', 'Gestion des comptes, des roles, des statuts et des codes de connexion'); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="toolbar">
        <form method="GET" class="toolbar-form">
            <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="Nom, email, code ou telephone">
            <button class="btn btn-secondary" type="submit">Filtrer</button>
            <a href="<?php echo e(route('users.index')); ?>" class="btn btn-secondary">Reinitialiser</a>
        </form>
    </div>
    <div class="table-responsive">
        <table>
            <thead><tr><th>Nom</th><th>Email</th><th>Code connexion</th><th>Role</th><th>Statut</th><th>Derniere connexion</th><th>Actions</th></tr></thead>
            <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <div class="user-inline">
                            <?php if($user->profile_photo_path): ?>
                                <img src="<?php echo e(asset('storage/' . $user->profile_photo_path)); ?>?v=<?php echo e($user->updated_at?->timestamp ?? time()); ?>" alt="Photo" class="profile-avatar">
                            <?php else: ?>
                                <div class="profile-avatar avatar-fallback"><?php echo e(strtoupper(substr($user->name, 0, 1))); ?></div>
                            <?php endif; ?>
                            <div>
                                <strong><?php echo e($user->name); ?></strong>
                                <div class="muted"><?php echo e($user->phone ?: 'Telephone non renseigne'); ?></div>
                            </div>
                        </div>
                    </td>
                    <td><?php echo e($user->email); ?></td>
                    <td><span class="pill"><?php echo e($user->login_code ?: 'Non defini'); ?></span></td>
                    <td><span class="status-badge <?php echo e($user->isAdministrator() ? 'status-admin' : 'status-employee'); ?>"><?php echo e($user->resolved_role_label); ?></span></td>
                    <td><span class="status-badge <?php echo e($user->is_active ? 'status-success' : 'status-danger'); ?>"><?php echo e($user->is_active ? 'Actif' : 'Suspendu'); ?></span></td>
                    <td><?php echo e(optional($user->last_login_at)?->format('d/m/Y H:i') ?: 'Jamais'); ?></td>
                    <td class="actions">
                        <a href="<?php echo e(route('users.edit', $user)); ?>" class="btn btn-secondary">Modifier</a>
                        <form method="POST" action="<?php echo e(route('users.destroy', $user)); ?>"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="btn btn-danger" type="submit">Supprimer</button></form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php echo e($users->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\IA-chart\resources\views\users\index.blade.php ENDPATH**/ ?>