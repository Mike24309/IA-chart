<?php $__env->startSection('page-title', 'Clients'); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="toolbar">
        <form method="GET" class="toolbar-form">
            <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="Nom, postnom, email, telephone ou entreprise">
            <button class="btn btn-secondary" type="submit">Filtrer</button>
            <a href="<?php echo e(route('clients.index')); ?>" class="btn btn-secondary">Reinitialiser</a>
        </form>
    </div>
    <div class="table-responsive">
        <table>
            <thead><tr><th>Nom complet</th><th>Email</th><th>Telephone</th><th>Entreprise</th><th>Actions</th></tr></thead>
            <tbody>
            <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e(trim($client->name . ' ' . ($client->post_name ?? ''))); ?></td>
                    <td><?php echo e($client->email); ?></td>
                    <td><?php echo e($client->phone); ?></td>
                    <td><?php echo e($client->company); ?></td>
                    <td class="actions">
                        <a href="<?php echo e(route('clients.edit', $client)); ?>" class="btn btn-secondary">Modifier</a>
                        <?php if(auth()->user()->isAdministrator()): ?>
                            <form method="POST" action="<?php echo e(route('clients.destroy', $client)); ?>"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button type="submit" class="btn btn-danger">Supprimer</button></form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php echo e($clients->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\IA-chart\resources\views\clients\index.blade.php ENDPATH**/ ?>