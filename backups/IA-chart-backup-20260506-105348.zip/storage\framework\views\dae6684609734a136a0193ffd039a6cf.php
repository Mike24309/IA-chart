<?php $__env->startSection('page-title', 'Dashboard'); ?>
<?php $__env->startSection('page-description', 'Pilotage commercial, stock et activite operationnelle'); ?>
<?php $__env->startSection('content'); ?>
<?php
    // Cette preparation convertit les notifications IA en tableau simple pour le JavaScript.
    $dashboardAiNotifications = $recentAiNotifications->map(function ($notification) {
        return [
            'title' => $notification->titre,
            'message' => $notification->message,
            'severity' => $notification->niveau_gravite,
        ];
    })->values();
?>

<section class="hero-banner <?php echo e(auth()->user()->isAdministrator() ? 'hero-admin' : 'hero-employee'); ?>">
    <div>
        
        <span class="eyebrow"><?php echo e(auth()->user()->isAdministrator() ? 'Vue direction' : 'Vue operationnelle'); ?></span>
        <h3><?php echo e(auth()->user()->isAdministrator() ? 'Centre de controle administrateur' : 'Espace employe oriente execution'); ?></h3>
        <p>
            <?php echo e(auth()->user()->isAdministrator()
                ? 'Surveillez le chiffre d affaires, le stock disponible, les utilisateurs actifs et les dernieres operations realisees.'
                : 'Creez vos factures, verifiez le stock disponible et accedez rapidement a votre profil.'); ?>

        </p>
    </div>
    <div class="hero-metrics">
        <?php if(auth()->user()->isAdministrator()): ?>
            <div>
                <span>CA du mois</span>
                <strong><?php echo e(number_format($monthlyRevenue, 2)); ?> <?php echo e($appSettings->currency); ?></strong>
            </div>
            <div>
                <span>Clients</span>
                <strong><?php echo e($clientCount); ?></strong>
            </div>
            <div>
                <span>Stocks a verifier</span>
                <strong><?php echo e($lowStockCount); ?></strong>
            </div>
        <?php else: ?>
            <div>
                <span>Mes factures</span>
                <strong><?php echo e($employeeInvoiceCount); ?></strong>
            </div>
            <div>
                <span>Produits actifs</span>
                <strong><?php echo e($productCount); ?></strong>
            </div>
            <div>
                <span>Stocks a verifier</span>
                <strong><?php echo e($lowStockCount); ?></strong>
            </div>
        <?php endif; ?>
    </div>
</section>

<?php if(! auth()->user()->isAdministrator()): ?>

<section class="stats-grid employee-quick-grid">
    <article class="card stat-card employee-stat-card"><span>Action principale</span><strong><span class="stat-card-value">Vendre</span></strong><a href="<?php echo e(route('invoices.create')); ?>" class="btn btn-primary">Nouvelle facture</a></article>
    <article class="card stat-card employee-stat-card"><span>Mes factures</span><strong><span class="stat-card-value"><?php echo e($employeeInvoiceCount); ?></span></strong><a href="<?php echo e(route('invoices.index')); ?>" class="btn btn-secondary">Voir mes factures</a></article>
    <article class="card stat-card employee-stat-card"><span>Stock disponible</span><strong><span class="stat-card-value"><?php echo e($productCount); ?></span></strong><a href="<?php echo e(route('products.index')); ?>" class="btn btn-secondary">Consulter le stock</a></article>
    <article class="card stat-card employee-stat-card"><span>Mon compte</span><strong><span class="stat-card-value">Profil</span></strong><a href="<?php echo e(route('profile.edit')); ?>" class="btn btn-secondary">Modifier mon profil</a></article>
</section>

<section class="content-grid dashboard-detail-grid employee-module-grid">
    <details class="card dashboard-module-toggle dashboard-module-card employee-module-card">
        <summary>
            <div>
                <strong>Mes dernieres factures</strong>
                <span class="muted">Ouvrir le detail de vos dernieres ventes</span>
            </div>
            <span class="status-badge status-info"><?php echo e(count($recentInvoices)); ?></span>
        </summary>
        <div class="dashboard-module-body table-responsive">
            <table>
                <thead><tr><th>Numero</th><th>Client</th><th>Date</th><th>Total TTC</th><th>Action</th></tr></thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $recentInvoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($invoice->invoice_number); ?></td>
                        <td><?php echo e($invoice->client->name); ?></td>
                        <td><?php echo e($invoice->invoice_date->format('d/m/Y')); ?></td>
                        <td><?php echo e(number_format($invoice->total_ttc, 2)); ?> <?php echo e($appSettings->currency); ?></td>
                        <td><a href="<?php echo e(route('invoices.show', $invoice)); ?>" class="btn btn-secondary">Voir</a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="5">Vous n avez pas encore cree de facture.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </details>

    <details class="card dashboard-module-toggle dashboard-module-card employee-module-card">
        <summary>
            <div>
                <strong>Stock disponible a surveiller</strong>
                <span class="muted">Ouvrir le detail des produits a surveiller</span>
            </div>
            <span class="status-badge status-danger"><?php echo e(count($lowStockProducts)); ?></span>
        </summary>
        <div class="dashboard-module-body table-responsive">
            <table>
                <thead><tr><th>Produit</th><th>Reference</th><th>Stock</th><th>Minimum</th></tr></thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $lowStockProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($product->name); ?></td>
                        <td><?php echo e($product->reference); ?></td>
                        <td><span class="status-badge status-danger"><?php echo e($product->stock); ?></span></td>
                        <td><?php echo e($product->minimum_stock); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="4">Aucun stock critique pour le moment.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </details>
</section>
<?php else: ?>

<section class="stats-grid">
    <article class="card stat-card">
        <span>CA global</span>
        <strong>
            <span class="stat-card-value"><?php echo e(number_format($totalRevenue, 2)); ?></span>
            <span class="stat-card-currency"><?php echo e($appSettings->currency); ?></span>
        </strong>
    </article>
    <article class="card stat-card">
        <span>CA mensuel</span>
        <strong>
            <span class="stat-card-value"><?php echo e(number_format($monthlyRevenue, 2)); ?></span>
            <span class="stat-card-currency"><?php echo e($appSettings->currency); ?></span>
        </strong>
    </article>
    <article class="card stat-card"><span>Factures</span><strong><span class="stat-card-value"><?php echo e($invoiceCount); ?></span></strong></article>
    <article class="card stat-card"><span>Produits</span><strong><span class="stat-card-value"><?php echo e($productCount); ?></span></strong></article>
    <article class="card stat-card"><span>Stock critique</span><strong><span class="stat-card-value"><?php echo e($lowStockCount); ?></span></strong></article>
    <article class="card stat-card"><span>Utilisateurs actifs</span><strong><span class="stat-card-value"><?php echo e($activeUsers); ?></span></strong></article>
</section>

<section class="card dashboard-ai-board">
    <div class="dashboard-ai-header">
        <div>
            <span class="eyebrow">Analyse IA</span>
            <h3>Espace d analyse principal</h3>
            <p class="muted">Choisissez vous-meme le type de graphique et la donnee a afficher dans un seul espace central, plus propre et plus lisible.</p>
            <div class="dashboard-ai-tags">
                <span class="pill">Ventes</span>
                <span class="pill">Stock</span>
                <span class="pill">Utilisateurs</span>
            </div>
        </div>
        <div class="dashboard-ai-toolbar">
            <details class="ai-bell-menu">
                <summary class="ai-bell-button">
                    <span class="ai-bell-icon">&#128276;</span>
                    <span>Notifications IA</span>
                    <span class="ai-bell-count" id="ai-bell-count"><?php echo e($unreadAiNotifications); ?></span>
                </summary>
                <div class="ai-bell-panel">
                    <div class="ai-bell-head">
                        <strong>Alertes recentes</strong>
                        <span class="muted">Module IA</span>
                    </div>
                    <div class="stack" id="ai-bell-list">
                        <?php $__empty_1 = true; $__currentLoopData = $recentAiNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="note">
                                <div class="note-head">
                                    <strong><?php echo e($notification->titre); ?></strong>
                                    <span class="status-badge <?php echo e($notification->niveau_gravite === 'eleve' ? 'status-danger' : ($notification->niveau_gravite === 'faible' ? 'status-success' : 'status-warning')); ?>"><?php echo e($notification->niveau_gravite); ?></span>
                                </div>
                                <div class="muted"><?php echo e($notification->message); ?></div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="muted">Aucune notification IA pour le moment.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </details>
            <div class="actions">
                <button type="button" class="btn btn-secondary" id="ai-run-local-analysis">Analyse locale</button>
                <button type="button" class="btn btn-primary" id="ai-run-analysis">Analyse avec IA</button>
                <button type="button" class="btn btn-secondary" id="ai-refresh-analysis">Rafraichir le dashboard IA</button>
            </div>
        </div>
    </div>

    <div id="ai-loading" class="dashboard-ai-loading" hidden aria-live="polite">
        <span class="dashboard-ai-loading-spinner" aria-hidden="true"></span>
        <div class="dashboard-ai-loading-text">
            <strong id="ai-loading-title">Analyse en cours...</strong>
            <span id="ai-loading-message">Veuillez patienter pendant que le module IA traite les donnees.</span>
        </div>
    </div>
    <div class="dashboard-photo-top">
        <article class="card dashboard-photo-card dashboard-photo-gauge">
            <div class="dashboard-photo-title">Note generale</div>
            <div class="ring-wrap dashboard-photo-ring">
                <canvas id="dashboard-ai-score-ring"></canvas>
                <strong id="dashboard-ai-score-text"><?php echo e($aiKpis['score']); ?>/100</strong>
            </div>
            <details class="dashboard-module-toggle dashboard-photo-toggle">
                <summary>
                    <div>
                        <strong>Details de la note</strong>
                        <span class="muted">Ouvrir les chiffres de lecture</span>
                    </div>
                    <span class="status-badge status-info">2</span>
                </summary>
                <div class="dashboard-module-body">
                    <div class="dashboard-photo-table">
                        <div><span>Gain realise</span><strong id="dashboard-ai-gross-margin"><?php echo e(number_format($aiKpis['grossMargin'], 2)); ?> <?php echo e($appSettings->currency); ?></strong></div>
                        <div><span>Vente moyenne</span><strong id="dashboard-ai-average-ticket"><?php echo e(number_format($aiKpis['averageTicket'], 2)); ?> <?php echo e($appSettings->currency); ?></strong></div>
                    </div>
                </div>
            </details>
        </article>

        <article class="card dashboard-photo-card dashboard-photo-gauge">
            <div class="dashboard-photo-title dashboard-photo-title-orange">Etat du stock</div>
            <div class="ring-wrap dashboard-photo-ring">
                <canvas id="dashboard-ai-stock-ring"></canvas>
                <strong id="dashboard-ai-stock-text"><?php echo e(number_format($aiKpis['stockHealth'], 0)); ?>%</strong>
            </div>
            <details class="dashboard-module-toggle dashboard-photo-toggle">
                <summary>
                    <div>
                        <strong>Details du stock</strong>
                        <span class="muted">Ouvrir les chiffres de surveillance</span>
                    </div>
                    <span class="status-badge status-warning">2</span>
                </summary>
                <div class="dashboard-module-body">
                    <div class="dashboard-photo-table">
                        <div><span>Produits a surveiller</span><strong id="dashboard-ai-low-stock"><?php echo e($lowStockCount); ?></strong></div>
                        <div><span>Annulations</span><strong id="dashboard-ai-cancel-text"><?php echo e(number_format($aiKpis['cancelRate'], 0)); ?>%</strong></div>
                    </div>
                </div>
            </details>
        </article>

        <article class="card dashboard-photo-card dashboard-photo-gauge">
            <div class="dashboard-photo-title">Utilisateurs</div>
            <div class="ring-wrap dashboard-photo-ring">
                <canvas id="dashboard-ai-user-ring"></canvas>
                <strong id="dashboard-ai-user-text"><?php echo e(number_format($aiKpis['activeUserRate'], 0)); ?>%</strong>
            </div>
            <details class="dashboard-module-toggle dashboard-photo-toggle">
                <summary>
                    <div>
                        <strong>Details utilisateurs</strong>
                        <span class="muted">Ouvrir les indicateurs d activite</span>
                    </div>
                    <span class="status-badge status-success">2</span>
                </summary>
                <div class="dashboard-module-body">
                    <div class="dashboard-photo-table">
                        <div><span>Alertes IA</span><strong id="ai-alert-count-inline">0</strong></div>
                        <div><span>Activite saine</span><strong id="dashboard-ai-meter-user-text"><?php echo e(number_format($aiKpis['activeUserRate'], 0)); ?>%</strong></div>
                    </div>
                </div>
            </details>
        </article>

        <article class="card dashboard-photo-card dashboard-photo-donut">
            <div class="dashboard-photo-title">Repartition des ventes</div>
            <div class="dashboard-ai-canvas-wrap dashboard-ai-canvas-wrap-small">
                <canvas id="dashboard-ai-product-share-chart"></canvas>
            </div>
        </article>
    </div>

    <div class="dashboard-photo-bottom">
        <article class="card dashboard-photo-card">
            <div class="dashboard-photo-title dashboard-photo-title-orange">Categories qui rapportent</div>
            <canvas id="dashboard-ai-category-chart"></canvas>
        </article>
        <article class="card dashboard-photo-card">
            <div class="dashboard-photo-title">Evolution du chiffre d affaire</div>
            <div class="dashboard-speedometer" id="dashboard-ai-speedometer">
                <div class="dashboard-speedometer-arc"></div>
                <div class="dashboard-speedometer-center">
                    <strong id="dashboard-ai-priority-score">0%</strong>
                    <span id="dashboard-ai-priority-label">Niveau faible</span>
                </div>
                <div class="dashboard-speedometer-needle" id="dashboard-ai-speedometer-needle"></div>
                <div class="dashboard-speedometer-mark mark-left">Faible</div>
                <div class="dashboard-speedometer-mark mark-center">Moyen</div>
                <div class="dashboard-speedometer-mark mark-right">Eleve</div>
            </div>
            <p class="muted dashboard-speedometer-caption" id="dashboard-ai-priority-caption">Le plan d action s affichera ici apres lecture des donnees.</p>
        </article>
    </div>

    <details class="card dashboard-module-toggle dashboard-module-card dashboard-photo-summary-toggle">
        <summary>
            <div>
                <strong>Synthese rapide IA</strong>
                <span class="muted">Ouvrir les chiffres resumes du module IA</span>
            </div>
            <span class="status-badge status-info">4</span>
        </summary>
        <div class="dashboard-module-body">
            <div class="dashboard-photo-strip">
                <div class="dashboard-photo-strip-item">
                    <span>Note generale</span>
                    <strong id="dashboard-ai-meter-score-text"><?php echo e($aiKpis['score']); ?>/100</strong>
                </div>
                <div class="dashboard-photo-strip-item">
                    <span>Etat du stock</span>
                    <strong id="dashboard-ai-meter-stock-text"><?php echo e(number_format($aiKpis['stockHealth'], 0)); ?>%</strong>
                </div>
                <div class="dashboard-photo-strip-item">
                    <span>Factures annulees</span>
                    <strong id="dashboard-ai-meter-cancel-text"><?php echo e(number_format($aiKpis['cancelRate'], 0)); ?>%</strong>
                </div>
                <div class="dashboard-photo-strip-item">
                    <span>Famille leader</span>
                    <strong id="dashboard-ai-top-category"><?php echo e($topCategory['label'] ?? 'Aucune categorie'); ?></strong>
                </div>
            </div>
        </div>
    </details>

    <div hidden>
        <canvas id="dashboard-ai-cancel-ring"></canvas>
        <span id="dashboard-ai-growth-badge"><?php echo e($monthlyGrowthRate >= 0 ? 'Hausse' : 'Baisse'); ?></span>
        <span id="dashboard-ai-growth-caption">Comparaison directe avec le mois precedent.</span>
        <span id="dashboard-ai-stock-alert-caption">Part des produits qui demandent une verification rapide.</span>
        <span id="dashboard-ai-priority-caption">Cette carte change apres chaque analyse.</span>
        <canvas id="dashboard-ai-stock-health-chart"></canvas>
        <span id="dashboard-ai-top-category-value"><?php echo e(isset($topCategory['value']) ? number_format((float) $topCategory['value'], 2) . ' ' . $appSettings->currency : '0'); ?></span>
        <span id="dashboard-ai-stock-alert-rate"><?php echo e(number_format($stockAlertRate, 1)); ?>%</span>
        <span id="dashboard-ai-priority-text"><?php echo e($lowStockCount > 0 ? 'Verifier les stocks sensibles' : 'Suivre les ventes du jour'); ?></span>
        <div class="dashboard-ai-meter-track"><div class="dashboard-ai-meter-fill" id="dashboard-ai-meter-score-fill" style="width: <?php echo e(min(100, max(0, $aiKpis['score']))); ?>%"></div></div>
        <div class="dashboard-ai-meter-track"><div class="dashboard-ai-meter-fill stock" id="dashboard-ai-meter-stock-fill" style="width: <?php echo e(min(100, max(0, $aiKpis['stockHealth']))); ?>%"></div></div>
        <div class="dashboard-ai-meter-track"><div class="dashboard-ai-meter-fill user" id="dashboard-ai-meter-user-fill" style="width: <?php echo e(min(100, max(0, $aiKpis['activeUserRate']))); ?>%"></div></div>
        <div class="dashboard-ai-meter-track"><div class="dashboard-ai-meter-fill warning" id="dashboard-ai-meter-cancel-fill" style="width: <?php echo e(min(100, max(0, $aiKpis['cancelRate']))); ?>%"></div></div>
    </div>
</section>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    window.aiRoutes = {
        analyze: "<?php echo e(route('ai.analyze')); ?>",
        ask: "<?php echo e(route('ai.ask')); ?>",
        report: "<?php echo e(route('ai.report')); ?>",
    };
    window.dashboardAiSeed = {
        monthlyRevenue: <?php echo json_encode($monthlySeries, 15, 512) ?>,
        categoryPerformance: <?php echo json_encode($categoryPerformance, 15, 512) ?>,
        categoryStock: <?php echo json_encode($categoryStock, 15, 512) ?>,
        score: <?php echo json_encode($aiKpis['score'], 15, 512) ?>,
        cancelRate: <?php echo json_encode($aiKpis['cancelRate'], 15, 512) ?>,
        stockHealth: <?php echo json_encode($aiKpis['stockHealth'], 15, 512) ?>,
        activeUserRate: <?php echo json_encode($aiKpis['activeUserRate'], 15, 512) ?>,
        grossMargin: <?php echo json_encode($aiKpis['grossMargin'], 15, 512) ?>,
        averageTicket: <?php echo json_encode($aiKpis['averageTicket'], 15, 512) ?>,
        lowStockCount: <?php echo json_encode($lowStockCount, 15, 512) ?>,
        monthlyGrowthRate: <?php echo json_encode($monthlyGrowthRate, 15, 512) ?>,
        stockAlertRate: <?php echo json_encode($stockAlertRate, 15, 512) ?>,
        topCategoryLabel: <?php echo json_encode($topCategory['label'] ?? 'Aucune categorie', 15, 512) ?>,
        topCategoryValue: <?php echo json_encode(isset($topCategory['value']) ? round((float) $topCategory['value'], 2) : 0, 512) ?>,
        currency: <?php echo json_encode($appSettings->currency, 15, 512) ?>,
        notifications: <?php echo json_encode($dashboardAiNotifications, 15, 512) ?>,
    };
</script>


<section class="dashboard-section-shell">
    <div class="dashboard-reading-stack">
        <div class="dashboard-reading-zone">
            <div class="dashboard-premium-grid dashboard-premium-grid-modules">
                <details class="card dashboard-module-toggle dashboard-module-card dashboard-block dashboard-block-table dashboard-block-invoices">
                    <summary>
                        <div>
                            <strong>Dernieres factures</strong>
                            <span class="muted">Afficher les dernieres factures en detail</span>
                        </div>
                        <span class="status-badge status-info"><?php echo e(count($recentInvoices)); ?></span>
                    </summary>
                    <div class="dashboard-module-body table-responsive">
                        <table>
                            <thead><tr><th>Numero</th><th>Client</th><th>Commercial</th><th>Total</th><th>Date</th></tr></thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $recentInvoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><a href="<?php echo e(route('invoices.show', $invoice)); ?>"><?php echo e($invoice->invoice_number); ?></a></td>
                                    <td><?php echo e($invoice->client->name); ?></td>
                                    <td><?php echo e($invoice->user->name); ?></td>
                                    <td><?php echo e(number_format($invoice->total_ttc, 2)); ?> <?php echo e($appSettings->currency); ?></td>
                                    <td><?php echo e($invoice->invoice_date->format('d/m/Y')); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="5">Aucune facture recente.</td></tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </details>

                <details class="card dashboard-module-toggle dashboard-module-card dashboard-block dashboard-block-list dashboard-block-ranking">
                    <summary>
                        <div>
                            <strong>Produits les plus vendus</strong>
                            <span class="muted">Afficher le detail des meilleurs produits</span>
                        </div>
                        <span class="status-badge status-success"><?php echo e(count($topProducts)); ?></span>
                    </summary>
                    <div class="dashboard-module-body">
                        <?php if(($maxProductAmount ?? 0) > 0): ?>
                            <div class="stack">
                                <?php $__currentLoopData = $topProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="metric-row">
                                        <div>
                                            <strong><?php echo e($product->description); ?></strong>
                                            <div class="muted"><?php echo e((int) $product->total_quantity); ?> unite(s) vendue(s)</div>
                                        </div>
                                        <div class="metric-progress">
                                            <div class="metric-progress-fill" style="width: <?php echo e(max(8, ($product->total_amount / $maxProductAmount) * 100)); ?>%"></div>
                                        </div>
                                        <strong><?php echo e(number_format($product->total_amount, 2)); ?></strong>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php else: ?>
                            <div class="chart-empty-state chart-empty-state-compact">
                                <strong>Aucun produit vendu pour le moment.</strong>
                                <span>Ce classement se remplira automatiquement apres les premieres ventes.</span>
                            </div>
                        <?php endif; ?>
                    </div>
                </details>
                <details class="card dashboard-module-toggle dashboard-module-card">
                    <summary>
                        <div>
                            <strong>Produits en alerte</strong>
                            <span class="muted">Ouvrir le detail du stock critique</span>
                        </div>
                        <span class="status-badge status-danger"><?php echo e($lowStockCount); ?></span>
                    </summary>
                    <div class="dashboard-module-body table-responsive">
                        <table>
                            <thead><tr><th>Produit</th><th>Reference</th><th>Stock</th><th>Minimum</th></tr></thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $lowStockProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($product->name); ?></td>
                                    <td><?php echo e($product->reference); ?></td>
                                    <td><span class="status-badge status-danger"><?php echo e($product->stock); ?></span></td>
                                    <td><?php echo e($product->minimum_stock); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="4">Aucun produit en alerte.</td></tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </details>

                <details class="card dashboard-module-toggle dashboard-module-card">
                    <summary>
                        <div>
                            <strong>Performance des utilisateurs</strong>
                            <span class="muted">Ouvrir le classement des ventes</span>
                        </div>
                        <span class="status-badge status-info"><?php echo e(count($topUsers)); ?></span>
                    </summary>
                    <div class="dashboard-module-body">
                        <?php if(($maxUserAmount ?? 0) > 0): ?>
                            <div class="stack">
                                <?php $__currentLoopData = $topUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="metric-row">
                                        <div>
                                            <strong><?php echo e($user->name); ?></strong>
                                            <div class="muted"><?php echo e($user->factures_count); ?> facture(s)</div>
                                        </div>
                                        <div class="metric-progress">
                                            <div class="metric-progress-fill accent" style="width: <?php echo e(max(8, (($user->total_revenue ?? 0) / $maxUserAmount) * 100)); ?>%"></div>
                                        </div>
                                        <strong><?php echo e(number_format((float) ($user->total_revenue ?? 0), 2)); ?></strong>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php else: ?>
                            <div class="chart-empty-state chart-empty-state-compact">
                                <strong>Aucune performance disponible.</strong>
                                <span>Les resultats des utilisateurs apparaitront ici apres les premieres factures.</span>
                            </div>
                        <?php endif; ?>
                    </div>
                </details>

                <details class="card dashboard-module-toggle dashboard-module-card">
                    <summary>
                        <div>
                            <strong>Acces rapides admin</strong>
                            <span class="muted">Ouvrir les actions principales</span>
                        </div>
                        <span class="status-badge status-success">3</span>
                    </summary>
                    <div class="dashboard-module-body stack">
                        <a href="<?php echo e(route('users.index')); ?>" class="btn btn-secondary">Gestion des utilisateurs</a>
                        <a href="<?php echo e(route('ai.settings.edit')); ?>" class="btn btn-secondary">Parametres IA</a>
                        <a href="<?php echo e(route('settings.edit')); ?>" class="btn btn-primary">Parametres generaux</a>
                    </div>
                </details>

                <details class="card dashboard-module-toggle dashboard-module-card">
                    <summary>
                        <div>
                            <strong>Derniers mouvements</strong>
                            <span class="muted">Ouvrir l historique recent du stock</span>
                        </div>
                        <span class="status-badge status-warning"><?php echo e(count($latestMovements)); ?></span>
                    </summary>
                    <div class="dashboard-module-body stack">
                        <?php $__empty_1 = true; $__currentLoopData = $latestMovements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="note">
                                <div class="note-head">
                                    <strong><?php echo e($movement->produit->name); ?></strong>
                                    <span class="status-badge <?php echo e($movement->movement_type === 'entree' ? 'status-success' : ($movement->movement_type === 'sortie' ? 'status-danger' : 'status-warning')); ?>"><?php echo e(ucfirst($movement->movement_type)); ?></span>
                                </div>
                                <div><?php echo e($movement->reason); ?></div>
                                <div class="muted"><?php echo e($movement->quantity); ?> unite(s) • <?php echo e($movement->user->name); ?> • <?php echo e($movement->movement_date->format('d/m/Y')); ?></div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="muted">Aucun mouvement recent.</p>
                        <?php endif; ?>
                    </div>
                </details>

                <details class="card dashboard-module-toggle dashboard-module-card">
                    <summary>
                        <div>
                            <strong>Activites recentes</strong>
                            <span class="muted">Ouvrir le journal des actions</span>
                        </div>
                        <span class="status-badge status-info"><?php echo e(count($recentActivities)); ?></span>
                    </summary>
                    <div class="dashboard-module-body">
                        <div class="stack">
                            <?php $__empty_1 = true; $__currentLoopData = $recentActivities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="note">
                                    <div class="note-head">
                                        <strong><?php echo e(str_replace('_', ' ', $activity->action)); ?></strong>
                                        <span class="status-badge status-info"><?php echo e($activity->created_at->format('d/m/Y H:i')); ?></span>
                                    </div>
                                    <div class="muted"><?php echo e($activity->user?->name ?: 'Systeme'); ?></div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p class="muted">Aucune activite recente.</p>
                            <?php endif; ?>
                        </div>
                        <div class="actions" style="margin-top: 12px;">
                            <a href="<?php echo e(route('activities.index')); ?>" class="btn btn-secondary">Voir tout</a>
                        </div>
                    </div>
                </details>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\IA-chart\resources\views\dashboard\index.blade.php ENDPATH**/ ?>