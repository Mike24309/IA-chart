
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mot de passe oublie - DEV IA</title>
    <?php if(file_exists(public_path('build/manifest.json'))): ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css']); ?>
    <?php else: ?>
        <link rel="stylesheet" href="<?php echo e(asset('app.css')); ?>?v=<?php echo e(filemtime(public_path('app.css'))); ?>">
    <?php endif; ?>
</head>
<body class="auth-page">
<div class="auth-shell">
    <div class="auth-card">
        <aside class="auth-brand-panel">
            <div class="auth-brand-wave auth-brand-wave-one"></div>
            <div class="auth-brand-wave auth-brand-wave-two"></div>
            <div class="auth-brand-content">
                <div class="auth-brand-logo">DI</div>
                <p class="auth-brand-eyebrow">Recuperation</p>
                <h1>DEV IA</h1>
            </div>
        </aside>

        <section class="auth-login-panel">
            <div class="auth-login-head">
                <p>Securite du compte</p>
                <h2>Mot de passe oublie</h2>
            </div>

            <?php if(session('success')): ?>
                <div class="alert alert-success auth-alert"><?php echo e(session('success')); ?></div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger auth-alert">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div><?php echo e($error); ?></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>

            <div class="auth-login-box">
                <form method="POST" action="<?php echo e(route('password.email')); ?>" class="auth-form-grid">
                    <?php echo csrf_field(); ?>
                    <div class="auth-register-note">
                        Entrez l adresse email de votre compte. Si elle existe, un lien de reinitialisation sera envoye.
                    </div>
                    <div>
                        <label for="email">Adresse email</label>
                        <input id="email" type="email" name="email" value="<?php echo e(old('email')); ?>" placeholder="Votre email" required>
                    </div>
                    <button class="btn auth-submit-btn" type="submit">Envoyer le lien</button>
                    <a href="<?php echo e(route('login')); ?>" class="auth-forgot-link">Retour a la connexion</a>
                </form>
            </div>
        </section>
    </div>
</div>
</body>
</html>
<?php /**PATH C:\laragon\www\IA-chart\resources\views\auth\forgot-password.blade.php ENDPATH**/ ?>