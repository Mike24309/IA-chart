<?php $__env->startSection('page-title', 'Catégories'); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="toolbar">
        <form method="GET" class="toolbar-form">
            <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="Nom ou description">
            <button class="btn btn-secondary" type="submit">Filtrer</button>
            <a href="<?php echo e(route('categories.index')); ?>" class="btn btn-secondary">Reinitialiser</a>
        </form>
    </div>
    <div class="table-responsive">
        <table>
            <thead><tr><th>Nom</th><th>Description</th><th>Actions</th></tr></thead>
            <tbody>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($category->name); ?></td>
                    <td><?php echo e($category->description); ?></td>
                    <td class="actions">
                        <a href="<?php echo e(route('categories.edit', $category)); ?>" class="btn btn-secondary">Modifier</a>
                        <form method="POST" action="<?php echo e(route('categories.destroy', $category)); ?>"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button type="submit" class="btn btn-danger">Supprimer</button></form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php echo e($categories->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\IA-chart\resources\views\categories\index.blade.php ENDPATH**/ ?>