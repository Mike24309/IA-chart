<?php $__env->startSection('page-title', 'Parametres IA'); ?>
<?php $__env->startSection('page-description', 'Seuils, modele Gemini, cache et comportement du module IA'); ?>
<?php $__env->startSection('content'); ?>
<form method="POST" action="<?php echo e(route('ai.settings.update')); ?>" class="card form-grid">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div><label>Seuil marge minimale</label><input type="number" step="0.01" name="minimum_margin_threshold" value="<?php echo e(old('minimum_margin_threshold', $settings->minimum_margin_threshold)); ?>" required></div>
    <div><label>Seuil stock critique</label><input type="number" name="critical_stock_threshold" value="<?php echo e(old('critical_stock_threshold', $settings->critical_stock_threshold)); ?>" required></div>
    <div><label>Sensibilite IA</label>
        <select name="sensitivity_level">
            <option value="faible" <?php if(old('sensitivity_level', $settings->sensitivity_level) === 'faible'): echo 'selected'; endif; ?>>Faible</option>
            <option value="moyenne" <?php if(old('sensitivity_level', $settings->sensitivity_level) === 'moyenne'): echo 'selected'; endif; ?>>Moyenne</option>
            <option value="elevee" <?php if(old('sensitivity_level', $settings->sensitivity_level) === 'elevee'): echo 'selected'; endif; ?>>Elevee</option>
        </select>
    </div>
    <div><label>Modele Gemini</label><input type="text" name="openrouter_model" value="<?php echo e(old('openrouter_model', $settings->openrouter_model)); ?>" required></div>
    <div><label>Duree cache (minutes)</label><input type="number" name="cache_duration_minutes" value="<?php echo e(old('cache_duration_minutes', $settings->cache_duration_minutes)); ?>" required></div>
    <div class="full form-checkbox-grid">
        <label class="checkbox"><input type="checkbox" name="enable_behavior_analysis" value="1" <?php if(old('enable_behavior_analysis', $settings->enable_behavior_analysis)): echo 'checked'; endif; ?>><span>Activer analyse comportementale</span></label>
        <label class="checkbox"><input type="checkbox" name="enable_daily_audit" value="1" <?php if(old('enable_daily_audit', $settings->enable_daily_audit)): echo 'checked'; endif; ?>><span>Activer audit quotidien automatique</span></label>
        <label class="checkbox"><input type="checkbox" name="enable_auto_alerts" value="1" <?php if(old('enable_auto_alerts', $settings->enable_auto_alerts)): echo 'checked'; endif; ?>><span>Activer alertes automatiques</span></label>
        <label class="checkbox"><input type="checkbox" name="enable_auto_pdf" value="1" <?php if(old('enable_auto_pdf', $settings->enable_auto_pdf)): echo 'checked'; endif; ?>><span>Activer generation PDF automatique</span></label>
        <label class="checkbox"><input type="checkbox" name="enable_realtime_mode" value="1" <?php if(old('enable_realtime_mode', $settings->enable_realtime_mode)): echo 'checked'; endif; ?>><span>Activer mode analyse temps reel</span></label>
    </div>
    <button class="btn btn-primary" type="submit">Enregistrer les parametres IA</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\IA-chart\resources\views\ai\settings.blade.php ENDPATH**/ ?>