<?php $__env->startSection('page-title', 'Mon profil'); ?>
<?php $__env->startSection('page-description', 'Informations personnelles et securite du compte'); ?>
<?php $__env->startSection('content'); ?>
<section class="profile-hero <?php echo e(auth()->user()->isAdministrator() ? 'profile-hero-admin' : 'profile-hero-employee'); ?>">
    <div class="profile-identity">
        
        <form method="POST" action="<?php echo e(route('profile.update')); ?>" enctype="multipart/form-data" class="profile-photo-form">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <input type="hidden" name="name" value="<?php echo e(auth()->user()->name); ?>">
            <input type="hidden" name="email" value="<?php echo e(auth()->user()->email); ?>">
            <input type="hidden" name="phone" value="<?php echo e(auth()->user()->phone); ?>">
            <label class="profile-photo-edit">
                <?php if(auth()->user()->profile_photo_path): ?>
                    <img src="<?php echo e(asset('storage/' . auth()->user()->profile_photo_path)); ?>?v=<?php echo e(auth()->user()->updated_at?->timestamp ?? time()); ?>" alt="Photo" class="profile-hero-avatar">
                <?php else: ?>
                    <div class="profile-hero-avatar avatar-fallback"><?php echo e(strtoupper(substr(auth()->user()->name, 0, 1))); ?></div>
                <?php endif; ?>
                <span>✎</span>
                <input type="file" name="profile_photo" accept="image/*" onchange="this.form.submit()">
            </label>
        </form>
        <div>
            
            <span class="eyebrow"><?php echo e(auth()->user()->resolved_role_label); ?></span>
            <h3><?php echo e(auth()->user()->name); ?></h3>
            <p><?php echo e(auth()->user()->isAdministrator() ? 'Vous disposez d un acces complet aux modules et au parametrage global.' : 'Vous disposez d un acces operationnel centre sur les ventes, les clients et le stock.'); ?></p>
        </div>
    </div>
    <div class="profile-summary">
        
        <div><span>Email</span><strong><?php echo e(auth()->user()->email); ?></strong></div>
        <div><span>Code connexion</span><strong><?php echo e(auth()->user()->login_code ?: 'Non defini'); ?></strong></div>
        <div><span>Derniere connexion</span><strong><?php echo e(optional(auth()->user()->last_login_at)?->format('d/m/Y H:i') ?: 'N/A'); ?></strong></div>
    </div>
</section>


<form method="POST" action="<?php echo e(route('profile.update')); ?>" enctype="multipart/form-data" class="card form-grid">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div><label>Nom</label><input type="text" name="name" value="<?php echo e(old('name', auth()->user()->name)); ?>" required></div>
    <div><label>Email</label><input type="email" name="email" value="<?php echo e(old('email', auth()->user()->email)); ?>" required></div>
    <div><label>Telephone</label><input type="text" name="phone" value="<?php echo e(old('phone', auth()->user()->phone)); ?>"></div>
    <div><label>Photo de profil</label><input type="file" name="profile_photo" accept="image/*"></div>
    <div><label>Nouveau mot de passe</label><input type="password" name="password"></div>
    <div><label>Confirmation</label><input type="password" name="password_confirmation"></div>
    <button class="btn btn-primary" type="submit">Mettre a jour</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\IA-chart\resources\views\profile\edit.blade.php ENDPATH**/ ?>