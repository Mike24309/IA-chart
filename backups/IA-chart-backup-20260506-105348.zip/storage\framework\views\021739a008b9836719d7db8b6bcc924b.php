<?php $__env->startSection('page-title', auth()->user()->isAdministrator() ? 'Produits' : 'Stock disponible'); ?>
<?php $__env->startSection('page-description', auth()->user()->isAdministrator() ? 'Gestion complete des produits' : 'Consultation simple des produits disponibles a la vente'); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="toolbar">
        
        <form method="GET" class="toolbar-form">
            <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="Produit, reference, categorie ou description">
            <button class="btn btn-secondary" type="submit">Filtrer</button>
            <a href="<?php echo e(route('products.index')); ?>" class="btn btn-secondary">Reinitialiser</a>
        </form>
    </div>
    
    <div class="table-responsive">
        <table>
            <thead>
            <?php if(auth()->user()->isAdministrator()): ?>
                <tr><th>Produit</th><th>Categorie</th><th>Prix vente</th><th>Stock</th><th>Actions</th></tr>
            <?php else: ?>
                <tr><th>Produit</th><th>Categorie</th><th>Prix vente</th><th>Stock disponible</th><th>Etat</th></tr>
            <?php endif; ?>
            </thead>
            <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($product->name); ?><div class="muted"><?php echo e($product->reference); ?></div></td>
                    <td><?php echo e($product->category?->name); ?></td>
                    <td><?php echo e(number_format($product->sale_price, 2)); ?></td>
                    <?php if(auth()->user()->isAdministrator()): ?>
                        
                        <td><?php echo e($product->stock); ?></td>
                        <td class="actions">
                            <a href="<?php echo e(route('products.edit', $product)); ?>" class="btn btn-secondary">Modifier</a>
                            <form method="POST" action="<?php echo e(route('products.destroy', $product)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger">Supprimer</button>
                            </form>
                        </td>
                    <?php else: ?>
                        
                        <td><?php echo e($product->stock); ?></td>
                        <td>
                            <?php if($product->isBelowMinimum()): ?>
                                <span class="status-badge status-danger">Stock bas</span>
                            <?php else: ?>
                                <span class="status-badge status-success">Disponible</span>
                            <?php endif; ?>
                        </td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    
    <?php echo e($products->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\IA-chart\resources\views\products\index.blade.php ENDPATH**/ ?>