<?php $__env->startSection('page-title', 'Voir la facture'); ?>
<?php $__env->startSection('page-description', 'Affichage complet de la facture avec le meme esprit visuel que le PDF'); ?>
<?php $__env->startSection('content'); ?>
<?php
    // Cette preparation calcule les valeurs utiles a l affichage detaille de la facture.
    $logoUrl = $settings->logo_path ? asset('storage/' . $settings->logo_path) . '?v=' . ($settings->updated_at?->timestamp ?? time()) : null;
    $backgroundUrl = $settings->invoice_background_path ? asset('storage/' . $settings->invoice_background_path) . '?v=' . ($settings->updated_at?->timestamp ?? time()) : null;
    $primaryColor = $settings->invoice_primary_color ?: '#1f6f97';
    $secondaryColor = $settings->invoice_secondary_color ?: '#eef4f8';
    $clientFullName = trim($invoice->client->name . ' ' . ($invoice->client->post_name ?? ''));
?>

<style>
    /* Ce bloc CSS controle toute la presentation visuelle de la facture a l ecran. */
    .invoice-show-layout {
        display: grid;
        grid-template-columns: minmax(0, 1fr) 280px;
        gap: 24px;
        align-items: start;
    }
    .invoice-view-shell {
        position: relative;
        overflow: hidden;
        border: 1px solid #d7e1e9;
        border-radius: 26px;
        background: #ffffff;
        padding: 24px;
        box-shadow: 0 24px 60px rgba(15, 23, 42, 0.08);
    }
    .invoice-view-watermark {
        position: absolute;
        inset: 0;
        background-position: center;
        background-repeat: no-repeat;
        background-size: cover;
        opacity: 0.05;
        pointer-events: none;
    }
    .invoice-view-body {
        position: relative;
        z-index: 1;
    }
    .invoice-view-header {
        display: grid;
        grid-template-columns: 130px 1fr 260px;
        gap: 18px;
        align-items: start;
    }
    .invoice-view-logo {
        width: 96px;
        height: 96px;
        border-radius: 20px;
        background: #f3f6fa;
        display: flex;
        align-items: center;
        justify-content: center;
        overflow: hidden;
        color: #0f172a;
        font-weight: 800;
    }
    .invoice-view-logo img {
        width: auto;
        height: auto;
        max-width: 100%;
        max-height: 100%;
        display: block;
        object-fit: contain;
    }
    .invoice-view-title {
        margin: 0;
        color: <?php echo e($primaryColor); ?>;
        font-size: 2rem;
        font-weight: 800;
        letter-spacing: 0.04em;
        text-transform: uppercase;
    }
    .invoice-view-company {
        margin-top: 12px;
        color: #64748b;
        line-height: 1.65;
    }
    .invoice-view-meta {
        border: 1px solid #dbe4ec;
        border-radius: 18px;
        overflow: hidden;
    }
    .invoice-view-meta-row {
        display: grid;
        grid-template-columns: 110px 1fr;
    }
    .invoice-view-meta-row span,
    .invoice-view-meta-row strong {
        padding: 10px 12px;
        border-bottom: 1px solid #e4ebf1;
        font-size: 0.92rem;
    }
    .invoice-view-meta-row:last-child span,
    .invoice-view-meta-row:last-child strong {
        border-bottom: none;
    }
    .invoice-view-meta-row span {
        background: #f8fafc;
        color: #64748b;
        text-transform: uppercase;
        font-size: 0.72rem;
        letter-spacing: 0.05em;
    }
    .invoice-view-party-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 14px;
        margin-top: 24px;
    }
    .invoice-view-party-card {
        border: 1px solid #dbe4ec;
        border-radius: 18px;
        overflow: hidden;
        background: #ffffff;
    }
    .invoice-view-party-head {
        padding: 10px 14px;
        background: <?php echo e($primaryColor); ?>;
        color: #ffffff;
        text-transform: uppercase;
        font-size: 0.74rem;
        letter-spacing: 0.08em;
        font-weight: 700;
    }
    .invoice-view-party-body {
        padding: 14px;
        min-height: 118px;
        color: #475569;
        line-height: 1.7;
    }
    .invoice-view-party-body strong {
        color: #0f172a;
    }
    .invoice-view-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 22px;
    }
    .invoice-view-table th,
    .invoice-view-table td {
        border: 1px solid #dbe4ec;
        padding: 11px 12px;
    }
    .invoice-view-table th {
        background: <?php echo e($primaryColor); ?>;
        color: #ffffff;
        text-transform: uppercase;
        font-size: 0.76rem;
        letter-spacing: 0.06em;
    }
    .invoice-view-table tbody tr:nth-child(even) td {
        background: #f8fafc;
    }
    .invoice-view-right {
        text-align: right;
    }
    .invoice-view-summary {
        display: flex;
        justify-content: flex-end;
        margin-top: 18px;
    }
    .invoice-view-summary table {
        width: 320px;
        border-collapse: collapse;
    }
    .invoice-view-summary td {
        border: 1px solid #dbe4ec;
        padding: 10px 12px;
    }
    .invoice-view-summary td:first-child {
        background: #f8fafc;
        color: #64748b;
        text-transform: uppercase;
        font-size: 0.74rem;
        letter-spacing: 0.05em;
    }
    .invoice-view-summary .grand td {
        background: <?php echo e($primaryColor); ?>;
        color: #ffffff;
        border-color: <?php echo e($primaryColor); ?>;
        font-weight: 700;
    }
    .invoice-view-footer {
        display: grid;
        grid-template-columns: 1.3fr 0.8fr;
        gap: 24px;
        margin-top: 24px;
    }
    .invoice-view-section-title {
        margin-bottom: 10px;
        color: <?php echo e($primaryColor); ?>;
        font-size: 0.76rem;
        text-transform: uppercase;
        letter-spacing: 0.08em;
        font-weight: 800;
    }
    .invoice-view-note {
        color: #475569;
        line-height: 1.7;
    }
    .invoice-view-signature {
        text-align: right;
    }
    .invoice-view-signature-mark {
        margin-top: 28px;
        font-size: 1.7rem;
        font-style: italic;
        color: #94a3b8;
    }
    .invoice-view-signature-line {
        display: inline-block;
        min-width: 190px;
        margin-top: 10px;
        padding-top: 8px;
        border-top: 1px solid #94a3b8;
        color: #64748b;
        text-transform: uppercase;
        font-size: 0.76rem;
    }
    .invoice-view-bank {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 14px;
        margin-top: 24px;
        padding-top: 18px;
        border-top: 1px solid #e2e8f0;
    }
    .invoice-view-bank-card {
        color: #475569;
        line-height: 1.7;
    }
    .invoice-view-chip {
        display: inline-block;
        padding: 6px 10px;
        border-radius: 999px;
        margin-bottom: 8px;
        background: <?php echo e($secondaryColor); ?>;
        color: <?php echo e($primaryColor); ?>;
        font-size: 0.72rem;
        font-weight: 700;
        text-transform: uppercase;
    }
    .invoice-view-footnote {
        margin-top: 14px;
        padding-top: 12px;
        border-top: 1px solid #e2e8f0;
        text-align: center;
        color: #64748b;
        font-size: 0.84rem;
    }
    .invoice-action-card {
        position: sticky;
        top: 24px;
    }
    @media (max-width: 1180px) {
        .invoice-show-layout {
            grid-template-columns: 1fr;
        }
        .invoice-action-card {
            position: static;
        }
    }
    @media (max-width: 900px) {
        .invoice-view-header,
        .invoice-view-party-grid,
        .invoice-view-footer,
        .invoice-view-bank {
            grid-template-columns: 1fr;
        }
    }
</style>

<div class="invoice-show-layout">
    
    <section class="invoice-view-shell">
        <?php if($backgroundUrl): ?>
            
            <div class="invoice-view-watermark" style="background-image: url('<?php echo e($backgroundUrl); ?>');"></div>
        <?php endif; ?>

        <div class="invoice-view-body">
            
            <div class="invoice-view-header">
                <div>
                    <div class="invoice-view-logo">
                        <?php if($logoUrl): ?>
                            <img src="<?php echo e($logoUrl); ?>" alt="Logo">
                        <?php else: ?>
                            GA
                        <?php endif; ?>
                    </div>
                </div>

                <div>
                    <h2 class="invoice-view-title"><?php echo e($settings->invoice_title ?: 'FACTURE'); ?></h2>
                    <div class="invoice-view-company">
                        <?php echo e($settings->company_name); ?><br>
                        <?php echo e($settings->company_address ?: 'Adresse entreprise'); ?><br>
                        <?php echo e($settings->company_email ?: 'Email entreprise'); ?><br>
                        <?php echo e($settings->company_phone ?: 'Telephone entreprise'); ?>

                    </div>
                </div>

                <div class="invoice-view-meta">
                    <div class="invoice-view-meta-row">
                        <span>Numero</span>
                        <strong><?php echo e($invoice->invoice_number); ?></strong>
                    </div>
                    <div class="invoice-view-meta-row">
                        <span>Date</span>
                        <strong><?php echo e($invoice->invoice_date->format('d/m/Y')); ?></strong>
                    </div>
                    <div class="invoice-view-meta-row">
                        <span>Echeance</span>
                        <strong><?php echo e($invoice->due_date?->format('d/m/Y') ?: 'A definir'); ?></strong>
                    </div>
                    <div class="invoice-view-meta-row">
                        <span>Commercial</span>
                        <strong><?php echo e($invoice->user->name); ?></strong>
                    </div>
                </div>
            </div>

            
            <div class="invoice-view-party-grid">
                <div class="invoice-view-party-card">
                    <div class="invoice-view-party-head"><?php echo e($settings->invoice_bill_from_label ?: 'Emetteur'); ?></div>
                    <div class="invoice-view-party-body">
                        <strong><?php echo e($settings->company_name); ?></strong><br>
                        <?php echo e($settings->company_address ?: 'Adresse entreprise'); ?><br>
                        <?php echo e($settings->company_email ?: 'Email entreprise'); ?><br>
                        <?php echo e($settings->company_phone ?: 'Telephone entreprise'); ?>

                    </div>
                </div>
                <div class="invoice-view-party-card">
                    <div class="invoice-view-party-head"><?php echo e($settings->invoice_bill_to_label ?: 'Facturer a'); ?></div>
                    <div class="invoice-view-party-body">
                        <strong><?php echo e($clientFullName); ?></strong><br>
                        <?php echo e($invoice->client->company ?: 'Entreprise client'); ?><br>
                        <?php echo e($invoice->client->address ?: 'Adresse client'); ?><br>
                        <?php echo e($invoice->client->email ?: 'Email client'); ?><br>
                        <?php echo e($invoice->client->phone ?: 'Telephone client'); ?>

                    </div>
                </div>
            </div>

            
            <table class="invoice-view-table">
                <thead>
                    <tr>
                        <th style="width: 46%;"><?php echo e($settings->invoice_description_label ?: 'Description'); ?></th>
                        <th style="width: 12%;" class="invoice-view-right"><?php echo e($settings->invoice_quantity_label ?: 'Qte'); ?></th>
                        <th style="width: 20%;" class="invoice-view-right"><?php echo e($settings->invoice_unit_price_label ?: 'Prix unitaire HT'); ?></th>
                        <th style="width: 22%;" class="invoice-view-right"><?php echo e($settings->invoice_amount_label ?: 'Montant HT'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $invoice->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($detail->description); ?></td>
                            <td class="invoice-view-right"><?php echo e($detail->quantity); ?></td>
                            <td class="invoice-view-right"><?php echo e(number_format($detail->unit_price_ht, 2)); ?> <?php echo e($settings->currency); ?></td>
                            <td class="invoice-view-right"><?php echo e(number_format($detail->line_total_ht, 2)); ?> <?php echo e($settings->currency); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            
            <div class="invoice-view-summary">
                <table>
                    <tr>
                        <td>Total HT</td>
                        <td class="invoice-view-right"><?php echo e(number_format($invoice->total_ht, 2)); ?> <?php echo e($settings->currency); ?></td>
                    </tr>
                    <tr>
                        <td>TVA <?php echo e(number_format($invoice->tax_rate, 2)); ?>%</td>
                        <td class="invoice-view-right"><?php echo e(number_format($invoice->tax_amount, 2)); ?> <?php echo e($settings->currency); ?></td>
                    </tr>
                    <tr class="grand">
                        <td>Total TTC</td>
                        <td class="invoice-view-right"><?php echo e(number_format($invoice->total_ttc, 2)); ?> <?php echo e($settings->currency); ?></td>
                    </tr>
                </table>
            </div>

            
            <div class="invoice-view-footer">
                <div>
                    <div class="invoice-view-section-title"><?php echo e($settings->invoice_payment_label ?: 'Conditions de paiement'); ?></div>
                    <div class="invoice-view-note"><?php echo e($settings->invoice_terms ?: 'Aucune condition particuliere renseignee.'); ?></div>
                </div>
                <div class="invoice-view-signature">
                    <?php if($settings->invoice_show_signature ?? true): ?>
                        <div class="invoice-view-signature-mark">Signature</div>
                        <div class="invoice-view-signature-line"><?php echo e($settings->invoice_signature_label ?: 'Signature autorisee'); ?></div>
                    <?php endif; ?>
                </div>
            </div>

            
            <div class="invoice-view-bank">
                <div class="invoice-view-bank-card">
                    <span class="invoice-view-chip"><?php echo e($settings->invoice_footer_bank_label ?: 'Banque'); ?></span><br>
                    <?php echo e($settings->bank_name ?: 'Non renseigne'); ?><br>
                    <?php echo e($settings->bank_account_name ?: 'Nom du compte non renseigne'); ?>

                </div>
                <div class="invoice-view-bank-card">
                    <span class="invoice-view-chip"><?php echo e($settings->invoice_footer_account_label ?: 'Compte'); ?></span><br>
                    <?php echo e($settings->bank_account_number ?: 'Numero non renseigne'); ?><br>
                    SWIFT : <?php echo e($settings->bank_swift ?: 'Non renseigne'); ?>

                </div>
                <div class="invoice-view-bank-card">
                    <span class="invoice-view-chip"><?php echo e($settings->invoice_footer_contact_label ?: 'Contact'); ?></span><br>
                    <?php echo e($settings->company_email ?: 'Email non renseigne'); ?><br>
                    <?php echo e($settings->company_phone ?: 'Telephone non renseigne'); ?>

                </div>
            </div>

            <?php if($settings->invoice_footer_note): ?>
                <div class="invoice-view-footnote"><?php echo e($settings->invoice_footer_note); ?></div>
            <?php endif; ?>
        </div>
    </section>

    
    <aside class="card stack invoice-action-card">
        <div class="card-head">
            <div>
                <h3>Actions facture</h3>
                <p class="muted">Cette vue reprend la presentation du PDF avant telechargement.</p>
            </div>
        </div>
        <div class="note">
            <strong><?php echo e($invoice->invoice_number); ?></strong>
            <div class="muted"><?php echo e(ucfirst($invoice->status)); ?></div>
        </div>
        
        <a href="<?php echo e(route('invoices.pdf', $invoice)); ?>" class="btn btn-secondary">Telecharger PDF</a>
        <?php if($invoice->client->email): ?>
            
            <form method="POST" action="<?php echo e(route('invoices.email', $invoice)); ?>">
                <?php echo csrf_field(); ?>
                <button class="btn btn-primary btn-block" type="submit">Envoyer par email</button>
            </form>
        <?php endif; ?>
        <?php if(auth()->user()->isAdministrator()): ?>
            
            <form method="POST" action="<?php echo e(route('invoices.destroy', $invoice)); ?>" onsubmit="return confirm('Supprimer cette facture et remettre le stock a jour ?');">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button class="btn btn-danger btn-block" type="submit">Supprimer la facture</button>
            </form>
        <?php endif; ?>
    </aside>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\IA-chart\resources\views\invoices\show.blade.php ENDPATH**/ ?>